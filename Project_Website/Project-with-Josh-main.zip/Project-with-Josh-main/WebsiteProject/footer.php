<footer>
    <p>&copy; 2024 Los Boyo's Hermanos. All Rights Reserved.</p>
</footer>

</body>
</html>
