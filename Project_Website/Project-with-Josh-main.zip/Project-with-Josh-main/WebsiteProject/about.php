<?php include 'header.php'; ?>

<h2>About Los Boyo's Hermanos</h2>
<p>Welcome to Los Boyo's Hermanos, your go-to spot for delicious, crispy fried chicken and fast-food meals.</p>

<?php include 'footer.php'; ?>
